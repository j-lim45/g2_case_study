class clearConsole {
    static void main() {
        System.out.print("\033\143");
    }
}