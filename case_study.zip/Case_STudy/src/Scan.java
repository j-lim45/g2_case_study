import java.util.Scanner;

class Scan {
    static Scanner caro = new Scanner(System.in);
}